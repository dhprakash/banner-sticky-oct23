// Trick Fixed Navbar

	  $(window).scroll(function(){
	  	  var scroll = $(window).scrollTop();
		  if (scroll > 300) {
		    $('.navbar').addClass('bg-scrolling');
		  }

		  else{
			$('.navbar').removeClass('bg-scrolling'); 	
		  }
  	  })